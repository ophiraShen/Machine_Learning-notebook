 

# Transformer

## transformer 是什么？

paper："Attention Is All You Need"  https://arxiv.org/abs/1706.03762



一个 **Sequence-to-sequence (Seq2seq)** 的model。

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228155905605.png" alt="image-20231228155905605" style="zoom:35%;" />   







## Seq2seq 模型

### 什么是 Seq2seq？

**Seq2seq ：Input a sequence, output a sequence. **

**输出由机器自己决定，不一定。**

Seq2seq 是一个很强大的模型，可以用到很多方面，例如：语音合成，聊天机器人，QA，文法分析，多标签分类，目标识别；

paper:

 "he Natural Language Decathlon: Multitask Learning as Question Answering"  https://arxiv.org/abs/1806.08730

"LAMOL: LAnguage MOdeling for Lifelong Language Learning"  https://arxiv.org/abs/1909.03329

"Grammar as a Foreign Language"  https://arxiv.org/abs/1412.7449

"Order-free Learning Alleviating Exposure Bias in Multi-label Classification"  https://arxiv.org/abs/1909.03434

"Order-Free RNN with Visual Attention for Multi-Label Classification"  https://arxiv.org/abs/1707.05495



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228160823153.png" alt="image-20231228160823153" style="zoom:30%;" /> <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228160914357.png" alt="image-20231228160914357" style="zoom:30%;" /> <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228161148359.png" alt="image-20231228161148359" style="zoom:30%;" />

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228161254711.png" alt="image-20231228161254711" style="zoom:30%;" />  <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228161341702.png" alt="image-20231228161341702" style="zoom:30%;" />  <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228161428357.png" alt="image-20231228161428357" style="zoom:30%;" />



paper: "Sequence to Sequence Learning with Neural Networks"   https://arxiv.org/abs/1409.321

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228161745733.png" alt="image-20231228161745733" style="zoom:40%;" /> 







## 模型架构

**Encoder + Decoder**



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231228235723442.png" alt="image-20231228235723442" style="zoom:50%;" />



### **Encoder**

做的事情：输入一排向量，输出一排向量。Transformer 的 Encoder 用的就是 Self-attention；



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229001255664.png" alt="image-20231229001255664" style="zoom:25%;" /> 



1、每一个 Block 的大概情形：

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229000214451.png" alt="image-20231229000214451" style="zoom:20%;" />  



2、在 Transformer 中，

​	1）使用了 **residual connection** 架构得到第一层输出（Self-attention）；

​	2）使用 **Layer Norm** 对第一层输出进行 normalize；

​	3）使用 **residual connection** 架构得到第二层输出（Fully connected）；

​	4）使用 **Layer Norm** 对第二层输出进行 normalize；得到一个 Block 的输出；

 

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229001032113.png" alt="image-20231229001032113" style="zoom:25%;" />  



**To learn more...**

Encoder 架构的其它设计方案

paper:

"On Layer Normalization in the Transformer Architecture"  https://arxiv.org/abs/2002.04745

"owerNorm: Rethinking Batch Normalization in Transformers"  https://arxiv.org/abs/2003.07845

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229001622974.png" alt="image-20231229001622974" style="zoom:25%;" /> 





### Decoder

做的事情：读入 Encoder 的输出，产生最终的输出。

Decoder 的核心仍然是 Self-attention，在此基础上做了一些改动。



**Autoregressive**

1、先从整体了解，Decoder 在读取 Encoder 的输出后，如何产生输出

​	1）BEGIN（ BOS）：一个特殊的符号，告诉 Decoder 开始；

​	2）经过 Decoder 之后，会生产一个向量，向量长度 = vocabulary size，例如，本例中是输出中文，则 vocabulary size 为中文字的		个数；每个字会有一个分数，代表可能性，分数最高的字，是最终的输出；

​	3）上一步的输出 "机"，加上 "BEGIN" 作为新一轮的输入；

​	4）重复 2）和 3）；

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229160613269.png" alt="image-20231229160613269" style="zoom:20%;" /> <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229160757944.png" alt="image-20231229160757944" style="zoom:21%;" />    



2、Decoder 中的细节，具体是怎么执行的

​	1）对比 Encoder 和 Decoder 对发现，除了中间被遮住的地方外，其余步骤基本一样；

​	2）在 Decoder 中，Multi-Head Attention 这个 Block 中多加了 **"Masked"** ；

​	3）**"Masked"**：在做 Self-attention 时，只考虑之前已有的输入信息，只与前面的 vector 计算相关性，不考虑后面的；



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229161753867.png" alt="image-20231229161753867" style="zoom:25%;" />     <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229161652110.png" alt="image-20231229161652110" style="zoom:25%;" /> 



3、如何让 Decoder 停止输出？

​	在输出向量中，添加 **"END"** 标志；

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229162223737.png" alt="image-20231229162223737" style="zoom:25%;" />  <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231229162243750.png" alt="image-20231229162243750" style="zoom:25%;" /> 





#### AT v.s. NAT

**AT:** Autoregressive;   **NAT:** Non - autoregressive

AT 是从 "BEGIN" 开始，依次生成输出；

NAT 同时给多个 "BEGIN"，一次性生产整个句子；

1.  NAT 中如何确定输出的长度？

   1. 新设一个 Classifier，得到 Encoder 的输出，输出一个数字，代表 Decoder 输出的长度；
   2.  提前人为预估一个足够的长度，NAT Decoder 产生输出后，以 "END" 为界限确定输出；

2. NAT 的好处：

   1. 可并行处理，AT 是依次产生输出，NAT 是一次性；（得益于 Self-attention）

   2. 可以控制输出的长度；

      比如：在做语音合成时，想要控制语速，将 Classifier 输出的长度除以2，速度就变为 2 倍；

      或者将 Classifier 的结果乘以 2 ，速度就变慢 2 倍；

3. 至今，NAT 的 Performance 一直比 AT 的差，主要因为 Multi - Modality；





### Encoder 和 Decoder 之间的传输

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230165307335.png" alt="image-20231230165307335" style="zoom:33%;" />



红框的地方是 Encoder 和 Decoder 链接的地方，总共有 3 个箭头，其中 2 个来自 Encoder，1 个来自 Decoder；



#### Cross attention：

paper: "Listen, attend and spell: A neural network for large vocabulary conversational speech recognition"  https://ieeexplore.ieee.org/document/7472621

​	1、**$q$ 来自 Decoder，$k, v$ 来自 Encoder；**



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230165943805.png" alt="image-20231230165943805" style="zoom:25%;" />   <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230170012727.png" alt="image-20231230170012727" style="zoom:25%;" /> 



2、不同的 Cross Attention 连接方式

​	Encoder 和 Decoder 各自都有很多层，到底是哪些层互相连接，也是一个研究方向。

paper: "Rethinking and Improving Natural Language Generation with Layer-Wise Multi-View Decoding"  https://arxiv.org/abs/2005.08081

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230170540363.png" alt="image-20231230170540363" style="zoom:25%;" /> 





## 模型训练

### 整体思路

类似 **分类问题**，以语音翻译为例：

​	1）Decoder 每次都会输出一个 vector，对应的我们还有一个正确的 Ground truth，如下图；

​	2）学习的目标是，输出的 vector 与正确的 Ground truth 越接近越好；例如，第一个字是 "机"，那么我们希望在输出的 vector 		中，"机" 的分数是最高的；

​	3）具体的方法是：计算输出的 vector 与 Ground truth 的 cross entropy；

​		目标是：总的 cross entropy 越小越好；

​	4）除了原本的 Label，还有最后的 "END" 也需要学习；



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230171640353.png" alt="image-20231230171640353" style="zoom:25%;" />  <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230171945208.png" alt="image-20231230171945208" style="zoom:25%;" /> 





### Teacher Forcing

​	1）在使用 Decoder 时，我们是将之前所有的输出，作为下一个输入；

​	2）但是在训练时，无论输出是什么，我们给 Decoder 的输入，永远是 **正确的输入；**

​	3）这样的训练方式叫做，**Teacher Forcing；**



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230172436401.png" alt="image-20231230172436401" style="zoom:25%;"/> 

  

### Tips

#### Copy Mechanism

paper:

"Get To The Point: Summarization with Pointer-Generator Networks"  https://arxiv.org/abs/1704.04368

"Incorporating Copying Mechanism in Sequence-to-Sequence Learning"  https://arxiv.org/abs/1603.06393

对于很多任务，实际上不需要 Decoder 自己创造新的内容，只需要它 **复制输入中的部分内容； **类似， Chat-bot，Summarization



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230175956786.png" alt="image-20231230175956786" style="zoom:15%;"/> <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230180415495.png" alt="image-20231230180415495" style="zoom:13%;" />       



#### Guided Attention

要求机器在做 Attention 时，有固定的方式，不是由机器随机进行的；

例如，在做语音合成时，要求机器严格从左向右，而不是跳跃的随机进行；

相关技术：

**1、Monotonic Attention：**单调注意力机制（Monotonic Attention）是一种用于序列到序列（sequence-to-sequence）模型中的注意力机制。在传统的注意力机制中，每个输出位置都可以从输入序列的所有位置获取信息，但是在某些任务中，特别是语音识别等领域，保持输出位置与输入位置的关系是很重要的。

Monotonic Attention 的主要思想是在生成输出序列的过程中，保持对应位置的输入和输出之间的单调性。具体来说，对于每个输出位置，模型会集中注意力于输入序列的一个子集，而不是整个序列。这个子集随着输出的生成逐渐移动，但保持了单调性，即不会跳跃或重叠。

这种注意力机制的优势在于对于实时性要求高的任务，可以更好地控制生成过程，减少不必要的计算，提高模型的效率。在语音识别等任务中，Monotonic Attention 被广泛应用，因为它可以更好地模拟人类在听取语音时的关注过程。

**2、Location-aware attention：**位置感知注意力机制，通常用于序列到序列（sequence-to-sequence）模型，特别是在语音合成（speech synthesis）等任务中。这种注意力机制的设计灵感来自于需要考虑生成序列时先前注意的位置信息。

在传统的注意力机制中，模型在生成每个输出位置时动态地分配权重给输入序列的不同部分。然而，在一些任务中，特别是语音合成中，需要考虑先前注意的区域，以保持生成序列的顺畅性和自然性。

Location-aware attention 的核心思想是将模型在先前步骤中的注意分布考虑进来。它通过维护一个累积的注意力分布，表示模型在输入序列的不同位置上的关注历史。在每个解码步骤中，模型会综合考虑当前的输入信息和已经关注的历史信息。

这样的设计使得模型不仅关注当前输入序列中的相关信息，还会考虑到先前关注的区域，从而避免生成冗余或不一致的关注。这对于一些任务，如语音合成，其中保持节奏或对齐模式很重要，有助于生成更连贯和自然的序列。

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230185825564.png" alt="image-20231230185825564" style="zoom:20%;"/>  



#### Beam Search

paper: "The Curious Case of Neural Text Degeneration"  https://arxiv.org/abs/1904.09751

假设 Decoder 只能产生 2 个输出，每次都是选择都是 "二选一"，最终得到一个总和最优的结果；



<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230190035849.png" alt="image-20231230190035849" style="zoom:15%;"/>    <img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230190151739.png" alt="image-20231230190151739" style="zoom:16%;" />





### Optimizing Evaluation Metrics

**BLUE score：**一种用于自动评估机器翻译系统输出质量的指标。它是通过比较机器生成的翻译与人工参考翻译之间的相似度来计算的。

方法：Decoder 产生一个完整的句子之后，再和正确答案作比较；是两个完整的句子之间的比较；

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230190814959.png" alt="image-20231230190814959" style="zoom:20%;" />  

在训练时，我们考虑的是 minimize cross entropy，考虑的是两个单个的词；所以在训练时，validation set 可以考虑用 BLUE score。

但是，在训练的时候不能使用 BLUE score，因为 BLUE score 不能微分，导致无法进行 gradient descend；所以我们采用 Cross entropy；

【trick：遇到无法 Optimize 的 Loss Function，可以把它当作 RL 的 Reward，把 Decoder 当作是 Agent，硬做。】

paper: "Sequence Level Training with Recurrent Neural Networks"  https://arxiv.org/abs/1511.06732





### mismach

训练时，Decoder 的输入永远是正确的，但是测试时，Decoder 的输入由上一步的输出决定，所以可能存在错误的输入。而 Decoder 在训练的时候没有接受过 "错误输入" 的训练，因此产生了 **mismach**，该如何解决呢？

**Schedule Sampling：**训练时，给 Decoder 一些错误的输入；但是会伤害到 Transformer 的并行能力；

<img src="/Users/shenyige/Library/Application Support/typora-user-images/image-20231230192013637.png" alt="image-20231230192013637" style="zoom:20%;" /> 

paper: 

"Scheduled Sampling for Sequence Prediction with Recurrent Neural Networks"  https://arxiv.org/abs/1506.03099

"Scheduled Sampling for Transformers"  https://arxiv.org/abs/1906.07651

"Parallel Scheduled Sampling"  https://arxiv.org/abs/1906.04331

